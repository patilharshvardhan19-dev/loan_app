# Final submission package — Credit Risk App
- Generated: Tue Sep  9 04:55:44 2025
- Contents: app.py, models/ (if any), outputs/ (if any), this report.

## Detected modeling features
['fico_score', 'dti_computed', 'loan_to_income', 'annual_inc', 'emp_length_years', 'has_delinquency', 'int_rate', 'installment', 'grade', 'purpose']

## Notes
- Model (if trained) saved at models/xgb_model.joblib inside package.